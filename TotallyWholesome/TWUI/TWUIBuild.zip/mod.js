cvr.menu.prototype.TWUI = {
    uiRef: {},
    breadcrumbs: [],
    currentPage: "",
    selectedPlayerID: "",
    selectedPlayerName: "",
    selectedAttachPage: "",
    selectedPetBone: "",
    selectedMasterBone: "",
    currentDraggedSlider: {},
    currentSliderBar: {},
    currentSliderKnob: {},
    setSliderFunction: {},
    isDragging: false,
    selectedPetID: "",
    selectedPetName: "",
    twShowAlertFunc: {},
    twAlertShown: false,
    twAlertToasts: [],

    info: function(){
        return {
            name: "Totally Wholesome",
            version_major: 0,
            version_minor: 1,
            description: "Totally Wholesome Menu",
            author: "DDAkebono",
            author_id: "",
            external_links: [
            ],
            stylesheets: [
                {filename: "TWUI.css", modes: ["quickmenu"]},
                {filename: "bootstrap-grid.min.css", modes: ["quickmenu"]}
            ],
            compatibility: [],
            icon: "TW_Logo_Pride-sm.png",
            feature_level: 1,
            supported_modes: ["quickmenu"]
        };
    },

    translation: function(menu){
        menu.translations["en"]["TWUI-title"] = "Totally Wholesome";
    },

    register: function(menu){
        uiRef = menu;
        breadcrumbs = [];
        players = [];
        currentPage = "MainPage";
        selectedPlayerID = "";
        selectedPlayerName = "";
        selectedAttachPage = "";
        selectedPetBone = "";
        selectedMasterBone = "";
        currentDraggedSlider = {};
        currentSliderBar = {};
        currentSliderKnob = {};
        isDragging = false;
        setSliderFunction = this.twSliderSetValue;
        selectedPetID = "";
        selectedPetName = "";
        twAlertToasts = [];
        twAlertShown = false;
        twShowAlertFunc = this.twShowAlert;

        console.log("Setting up TWUI");

        menu.templates["twUI-btn"] = {c: "twUI-btn hidden", s: [{c: "icon"}, {c: "status-background hidden", a:{"id": "twUI-status-bg"}}, {c: "status-pet hidden", a:{"id": "twUI-status-pet"}}, {c: "status-master hidden", a:{"id": "twUI-status-master"}}, {c: "status-icon-shock hidden", a:{"id": "twUI-status-icon-shock"}}, {c: "status-icon-vibrate hidden", a:{"id": "twUI-status-icon-vibrate"}}, {c: "badge hidden", a:{"id": "twUI-badge"}, s:[{c: "badge-text", a:{"id": "twUI-badgeText"}, h:"DEV"}]}], x: "twUI-open", a:{"id":"twUI-QMButton"}};
        menu.templates["twUI-menu"] = {c: "twUI menu-category hide", s: [
                {c: "container container-main", s:[
                        {c:"row", s:[
                                {c:"col", s:[
                                        {c: "header", h: "Totally Wholesome"},
                                        {c: "content", s:[
                                                {c: "user-count", h: "Connected Users: Disconnected"},
                                            ]}
                                    ]},
                                {c:"col-auto mr-auto", s:[{c:"icon-useradd", x:"twUI-pushPage", a:{"data-page": "PlayerList"}}]}
                            ]}
                    ]},
                {c: "container container-controls", a:{"id": "twUI-MainPage"}, s:[{c: "scroll-view", s:[{c: "content scroll-content", s:[
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Controls"}]}
                                    ]},
                                {c: "row", s:[
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-close"}, {c:"text", h:"Remove Leashes"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Remove all leashes connected to you", "data-action": "clearLeads"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-trash"}, {c:"text", h:"Clear Notifications"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Clears all pending notifications", "data-action": "clearNotifs"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-settings"}, {c:"text", h:"TW Settings"}], x: "twUI-pushPage", a:{"data-page": "SettingsPage", "data-tooltip": "Adjust your Totally Wholesome settings"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-profile"}, {c:"text", h:"My TW"}], x: "twUI-pushPage", a:{"data-page": "StatusPage", "data-tooltip": "Configure your Totally Wholesome status, view achievements, and other various functions!"}}]},
                                        {c:"col-3", s:[{c: "toggle", s:[
                                                    {c:"row", s:[
                                                            {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                            {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                        ]},
                                                    {c:"text", h:"Gag Pet"}
                                                ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-GagPet","data-toggle": "GagPet", "data-toggleState": "false", "data-tooltip": "Gag your pets"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-ability"}, {c:"text", h:"More Pet Restrictions"}], x: "twUI-pushPage", a:{"data-tooltip": "Access additional pet restrictions, movement, blindness, deafening, world pinning and more!", "data-page": "MovementControlPage"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-body"}, {c:"text", h:"Avatar Remote Config"}], x: "twUI-pushPage", a:{"data-tooltip": "Choose what parameters your master can control", "data-page": "AvatarRemoteConfig"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-tw-multiuser"}, {c:"text", h:"Individual Pet Controls"}], x: "twUI-pushPage", a:{"data-tooltip": "Control your pets settings individually", "data-page": "IndividualPetControl"}}]},
                                    ]},
                                {c: "row", a:{"id": "twUI-ControlsSliderRoot"}},
                                {c:"piShockElements", s: [
                                        {c: "row", s:[
                                            {c:"col", s:[{c:"header", h:"PiShock Controls"}]}
                                        ]},
                                        {c: "row", s:[
                                                {c:"col-3", s:[{c: "button", s:[{c:"icon-volume"}, {c:"text", h:"Beep"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Sends a beep event to each of your pets active shocker", "data-action": "pishockBeep"}}]},
                                                {c:"col-3", s:[{c: "button", s:[{c:"icon-star"}, {c:"text", h:"Vibrate"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Sends a vibrate event to each of your pets active shocker", "data-action": "pishockVibrate"}}]},
                                                {c:"col-3", s:[{c: "button", s:[{c:"icon-bolt"}, {c:"text", h:"Shock"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Sends a shock event to each of your pets active shocker", "data-action": "pishockShock"}}]},
                                                {c:"col-3", s:[{c: "toggle", s:[
                                                            {c:"row", s:[
                                                                    {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                    {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                                ]},
                                                            {c:"text", h:"Height Control"}
                                                        ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-HeightControl", "data-toggle": "HeightControl", "data-toggleState": "false", "data-tooltip": "Enable the height control system"}}]}
                                            ]},
                                        {c: "row", a:{"id": "twUI-PiShockSliderRoot"}},]},
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-MovementControlPage"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Global Restriction Options"}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                    {c: "row", s:[
                                            {c:"col", s:[{c:"header", h:"Basic Controls"}]}
                                        ]},
                                    {c:"row", s: [
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Temp Leash Unlock"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-TempLeashUnlock","data-toggle": "TempLeashUnlock", "data-toggleState": "false", "data-tooltip": "Temporarily unlock the leashes of your pets"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Disallow Flight"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-DisableFlight","data-toggle": "DisableFlight", "data-toggleState": "false", "data-tooltip": "Disables the pet's ability to use flight"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Disallow Seats"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-DisableSeats","data-toggle": "DisableSeats", "data-toggleState": "false", "data-tooltip": "Disables the pet's ability to use seats/stations"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Blindfold"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-Blindfold","data-toggle": "Blindfold", "data-toggleState": "false", "data-tooltip": "Blindfolds all pets"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Deafen"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-Deafen","data-toggle": "Deafen", "data-toggleState": "false", "data-tooltip": "Deafens all pets"}}]},
                                        ]},
                                    {c: "row", s:[
                                            {c:"col", s:[{c:"header", h:"World/Prop Pinning"}]}
                                        ]},
                                    {c: "row", s:[
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-aim"}, {c:"text", h:"Set World Pin"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Allows you to choose a new position in the world to attach the leash to", "data-action": "selectWorldPosition"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Lock Leash to World Pin"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-LockToWorld","data-toggle": "LockToWorld", "data-toggleState": "false", "data-tooltip": "Locks the pets leash to a configured world position"}}]},
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-list"}, {c:"text", h:"Select Bound Prop"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Allows you to choose a prop you want the leash attached to", "data-action": "selectBoundProp"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Lock Leash to Prop"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-LockToProp","data-toggle": "LockToProp", "data-toggleState": "false", "data-tooltip": "Locks the pets leash to a prop"}}]},
                                        ]},
                                ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-MovementControlPageIPC"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Restriction Options", a: {"id":"twUI-MovementControlHeaderIPC"}}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                    {c: "row", s:[
                                            {c:"col", s:[{c:"header", h:"Basic Controls"}]}
                                        ]},
                                    {c:"row", s: [
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Temp Leash Unlock"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-TempLeashUnlockIPC","data-toggle": "TempLeashUnlockIPC", "data-toggleState": "false", "data-tooltip": "Temporarily unlock the leashes of your pets"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Disallow Flight"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-DisableFlightIPC","data-toggle": "DisableFlightIPC", "data-toggleState": "false", "data-tooltip": "Disables the pet's ability to use flight"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Disallow Seats"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-DisableSeatsIPC","data-toggle": "DisableSeatsIPC", "data-toggleState": "false", "data-tooltip": "Disables the pet's ability to use seats/stations"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                                {c:"row", s:[
                                                                        {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                        {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                                    ]},
                                                                {c:"text", h:"Blindfold"}
                                                            ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-BlindfoldIPC","data-toggle": "BlindfoldIPC", "data-toggleState": "false", "data-tooltip": "Blindfolds the selected pet"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Deafen"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-DeafenIPC","data-toggle": "DeafenIPC", "data-toggleState": "false", "data-tooltip": "Deafens the selected pet"}}]},
                                        ]},
                                    {c: "row", s:[
                                            {c:"col", s:[{c:"header", h:"World/Prop Pinning"}]}
                                        ]},
                                    {c: "row", s:[
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-aim"}, {c:"text", h:"Set World Pin"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Allows you to choose a new position in the world to attach the leash to", "data-action": "selectWorldPositionIPC"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Lock Leash to World Pin"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-LockToWorldIPC","data-toggle": "LockToWorldIPC", "data-toggleState": "false", "data-tooltip": "Locks the pets leash to a configured world position"}}]},
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-list"}, {c:"text", h:"Select Bound Prop"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Allows you to choose a prop you want the leash attached to", "data-action": "selectBoundPropIPC"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Lock Leash to Prop"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-LockToPropIPC","data-toggle": "LockToPropIPC", "data-toggleState": "false", "data-tooltip": "Locks the pets leash to a prop"}}]},
                                        ]},
                                ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-SettingsPage"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Settings"}]}
                        ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"General"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-Settings-General"}, s:[
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-twTab"}, {c:"text", h:"TW Branches"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Switch the active branch of Totally Wholesome you're using", "data-action": "changeBranch"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-turnoff"}, {c:"text", h:"Restart Buttplug"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Restarts the Buttplug Connector. This kills any running Intiface CLI Process", "data-action": "restartButtplug"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-star"}, {c:"text", h:"Test Toys"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Activates your toys for a second.", "data-action": "testToys"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-star"}, {c:"text", h:"Reload Config"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Reloads the TW Config", "data-action": "reloadConfig"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-list"}, {c:"text", h:"Menu Settings"}], x: "twUI-pushPage", a:{"data-page": "MenuVisibilityPage", "data-tooltip": "Control the visibility and position of some menu elements"}}]},
                                    ]},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Master"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-Settings-Master"}, s:[
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-body"}, {c:"text", h:"Master Lead Attach Point"}], x: "twUI-leadAttachPage", a:{"data-tooltip": "Select where you would like the lead to be attached to", "data-attach": "master"}}]},
                                    ]},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Pet"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-Settings-Pet"}, s:[
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-body"}, {c:"text", h:"Pet Lead Attach Point"}], x: "twUI-leadAttachPage", a:{"data-tooltip": "Select where you would like the lead to be attached to", "data-attach": "pet"}}]},
                                    ]},
                                    {c: "row", a:{"id": "twUI-PetBlindnessSlider"}},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"PiShock"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-Settings-PiShock"}, s: [
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-list"}, {c:"text", h:"Shocker Management"}], x: "twUI-pushPage", a:{"data-page": "ShockerManagement", "data-tooltip": "Manager your PiShock Shockers"}}]},
                                    ]},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"TWNet"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-Settings-TWNet"}, s:[
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-exit"}, {c:"text", h:"Disconnect From TWNet"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Disconnects you from TWNet, you will need to manually reconnect!", "data-action": "disconnectTWNet"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-reload"}, {c:"text", h:"Reconnect to TWNet"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Starts a reconnection to TWNet, only use this if you are having trouble reconnecting automatically!", "data-action": "reconnectTWNet"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-list"}, {c:"text", h:"Leash Style"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Opens up the selection page for leash styles", "data-action": "selectLeashStyle"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-settings"}, {c:"text", h:"Leash Color Config"}], x: "twUI-pushPage", a:{"data-page": "LeashColorConfig", "data-tooltip": "Change the color of your leash"}}]},
                                    ]},
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-StatusPage"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"My TW"}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c: "row", s:[
                                        {c:"col-3", s:[{c: "toggle", s:[
                                                    {c:"row", s:[
                                                            {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                            {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                        ]},
                                                    {c:"text", h:"Enable Status"}
                                                ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-EnableStatus","data-toggle": "EnableStatus", "data-toggleState": "false", "data-tooltip": "Choose if you want your Totally Wholesome status to be broadcast to other TW users in your world"}}]},
                                        {c:"col-3", s:[{c: "toggle", s:[
                                                    {c:"row", s:[
                                                            {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                            {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                        ]},
                                                    {c:"text", h:"Display Special Badge"}
                                                ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-DisplaySpecialBadge","data-toggle": "DisplaySpecialBadge", "data-toggleState": "false", "data-tooltip": "Enables your special badge if you have one, if you've helped with testing you might have one!"}}]},
                                        {c:"col-3", s:[{c: "toggle", s:[
                                                    {c:"row", s:[
                                                            {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                            {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                        ]},
                                                    {c:"text", h:"Hide Status in Publics"}
                                                ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-HideInPublics","data-toggle": "HideInPublics", "data-toggleState": "false", "data-tooltip": "Hides your Totally Wholesome status in public worlds"}}]},
                                        {c:"col-3", s:[{c: "toggle", s:[
                                                    {c:"row", s:[
                                                            {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                            {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                        ]},
                                                    {c:"text", h:"Show Device Status"}
                                                ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-ShowDeviceStatus","data-toggle": "ShowDeviceStatus", "data-toggleState": "false", "data-tooltip": "Toggles the visibility of your buttplug/pishock devices on your status"}}]},
                                        {c:"col-3", s:[{c: "toggle", s:[
                                                    {c:"row", s:[
                                                            {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                            {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                        ]},
                                                    {c:"text", h:"Show Auto Accept"}
                                                ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-ShowAutoAccept","data-toggle": "ShowAutoAccept", "data-toggleState": "false", "data-tooltip": "Toggle the visibility of your auto accept status"}}]},
                                        {c: "col-3", s:[{c: "button", s:[{c:"icon-key"}, {c:"text", h:"Enter Rank Key"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Enter the key given to you to enable your special rank in Totally Wholesome", "data-action": "enterRankKey"}}]},
                                        {c: "col-3", s:[{c: "button", s:[{c:"icon-badgeGold"}, {c:"text", h:"My Achievements"}], x: "twUI-pushPage", a:{"data-page": "MyAchievements", "data-tooltip": "View the achievements you've earned!"}}]},
                                    ]},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Misc"}]}
                                    ]},
                                {c: "row", s:[
                                        {c: "col", s:[{c: "button", s:[{c:"icon-discord"}, {c:"text", h:"Join Our Discord!"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Opens up the invite link to the Totally Wholesome Discord!", "data-action": "joinDiscord"}}]},
                                        {c: "col", s:[{c: "button", s:[{c:"icon-bolt"}, {c:"text", h:"PiShock Homepage"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Opens up the PiShock homepage", "data-action": "openPiShock"}}]},
                                        {c: "col", s:[{c: "button", s:[{c:"icon-link"}, {c:"text", h:"Licences"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Click here to go to the 3rd party library licenses page", "data-action": "openLicences"}}]},
                                        {c: "col", s:[{c: "button", s:[{c:"icon-link"}, {c:"text", h:"EULA"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Click here to view the Totally Wholesome EULA", "data-action": "openEULA"}}]}
                                    ]}
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-PlayerList"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Players"}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c: "row", a:{"id": "twUI-PlayerListContent"}}
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-PlayerSelectPage"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"User", a:{"id": "twUI-PlayerSelectHeader"}}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c: "row", s:[
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-crown"}, {c:"text", h:"Make Master"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Sends a master request to the selected user", "data-action": "requestPet"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-link"}, {c:"text", h:"Make Pet"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Sends a follower request to the selected user", "data-action": "requestMaster"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-list"}, {c:"text", h:"Manage User"}], x: "twUI-OpenUserManage", a:{"data-tooltip": "Manage user settings for this user"}}]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-list"}, {c:"text", h:"Remote Param Control"}], x: "twUI-OpenParamControlUserMan", a:{"data-tooltip": "Shortcut to remote param control for this user"}}]}
                                    ]},
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-LeadAttachPage"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Lead Attach", a:{"id": "twUI-leadAttachHeader"}}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Selected Bone: ", a:{"id": "twUI-SelectedBone"}}]}
                                    ]},
                                {c: "row", s:[
                                        {c: "col-3", s:[{c: "button", s:[{c:"text", h:"Neck"}], x: "twUI-LeadAttachAssign", a:{"data-tooltip": "Attach the lead to Neck", "data-bone": "Neck"}}]},
                                        {c: "col-3", s:[{c: "button", s:[{c:"text", h:"Spine"}], x: "twUI-LeadAttachAssign", a:{"data-tooltip": "Attach the lead to Spine", "data-bone": "Spine"}}]},
                                        {c: "col-3", s:[{c: "button", s:[{c:"text", h:"Hips"}], x: "twUI-LeadAttachAssign", a:{"data-tooltip": "Attach the lead to Hips", "data-bone": "Hips"}}]},
                                        {c: "col-3", s:[{c: "button", s:[{c:"text", h:"LeftFoot"}], x: "twUI-LeadAttachAssign", a:{"data-tooltip": "Attach the lead to Left Foot", "data-bone": "LeftFoot"}}]},
                                        {c: "col-3", s:[{c: "button", s:[{c:"text", h:"RightFoot"}], x: "twUI-LeadAttachAssign", a:{"data-tooltip": "Attach the lead to Right Foot", "data-bone": "RightFoot"}}]},
                                        {c: "col-3", s:[{c: "button", s:[{c:"text", h:"LeftHand"}], x: "twUI-LeadAttachAssign", a:{"data-tooltip": "Attach the lead to Left Hand", "data-bone": "LeftHand"}}]},
                                        {c: "col-3", s:[{c: "button", s:[{c:"text", h:"RightHand"}], x: "twUI-LeadAttachAssign", a:{"data-tooltip": "Attach the lead to Right Hand", "data-bone": "RightHand"}}]},
                                    ]}
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-PermissionsMenuUsers"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Manage User: ", a:{"id": "twUI-UserPermManageHeader"}}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"General"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-UserPerms-General"}, s:[]},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Master"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-UserPerms-Master"}, s:[]},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Pet"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-UserPerms-Pet"}, s:[]},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"PiShock"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-UserPerms-PiShock"}},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"TWNet"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-UserPerms-TWNet"}},
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-AvatarRemoteConfig"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Avatar Remote Config - 0/12 Selected", a:{"id": "twUI-AvatarRemoteConfigHeader"}}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Parameters"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-AvatarRemote-FloatParams"}},
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-IndividualPetControl"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Individual Pet Control"}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                    {c: "row", s:[{c:"col", s:[{c:"header", h:"Selected Pet: None", a:{"id": "twUI-PetSelectionHeader"}}]}]},
                                    {c: "row", a:{"id": "twUI-PetSelectionRoot"}},
                                    {c: "row", s:[{c:"col", s:[{c:"header", h:"Controls"}]}]},
                                    {c: "row", s:[
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-list"}, {c:"text", h:"Remote Param Control"}], x: "twUI-OpenParamControlIPC", a:{"data-tooltip": "Opens the remote parameter control for the selected pet"}}]},
                                            {c:"col-3", s:[{c: "toggle", s:[
                                                        {c:"row", s:[
                                                                {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                            ]},
                                                        {c:"text", h:"Gag Pet"}
                                                    ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-GagPetIPC","data-toggle": "GagPetIPC", "data-toggleState": "false", "data-tooltip": "Gags the selected pet"}}]},
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-ability"}, {c:"text", h:"More Pet Restrictions"}], x: "twUI-pushPage", a:{"data-tooltip": "Access additional pet restrictions, movement, blindness, deafening, world pinning and more!", "data-page": "MovementControlPageIPC"}}]},
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-close"}, {c:"text", h:"Remove Leash"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Removes the leash from this pet", "data-action": "removeLeashIPC"}}]},
                                        ]},
                                    {c: "row", a:{"id": "twUI-IPCControlsSliderRoot"}},
                                    {c:"piShockElements", s: [
                                            {c: "row", s:[
                                                    {c:"col", s:[{c:"header", h:"PiShock Controls"}]}
                                                ]},
                                            {c: "row", s:[
                                                    {c:"col-3", s:[{c: "button", s:[{c:"icon-volume"}, {c:"text", h:"Beep"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Sends a beep event to the selected pets shocker", "data-action": "pishockBeepIPC"}}]},
                                                    {c:"col-3", s:[{c: "button", s:[{c:"icon-star"}, {c:"text", h:"Vibrate"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Sends a vibrate event to the selected pets shocker", "data-action": "pishockVibrateIPC"}}]},
                                                    {c:"col-3", s:[{c: "button", s:[{c:"icon-bolt"}, {c:"text", h:"Shock"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Sends a shock event to the selected pets shocker", "data-action": "pishockShockIPC"}}]},
                                                    {c:"col-3", s:[{c: "toggle", s:[
                                                                {c:"row", s:[
                                                                        {c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]},
                                                                        {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}
                                                                    ]},
                                                                {c:"text", h:"Height Control"}
                                                            ], x: "twUI-Toggle", a:{"id": "twUI-Toggle-HeightControlIPC", "data-toggle": "HeightControlIPC", "data-toggleState": "false", "data-tooltip": "Enable the height control system"}}]}
                                                ]},
                                            {c: "row", a:{"id": "twUI-IPCPiShockSliderRoot"}},
                                        ]},
                                ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-RemoteParamControl"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Remote Param Control"}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Multi Selection"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-RemoteControl-MultiSelection"}},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Singles"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-RemoteControl-SingleInput"}},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Toggles"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-RemoteControl-AvatarButtons"}},
                                {c: "row", s:[
                                        {c:"col", s:[{c:"header", h:"Sliders"}]}
                                    ]},
                                {c:"row", a:{"id": "twUI-RemoteControl-SliderRoot"}},
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-DropdownPage"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Dropdown", a:{"id": "twUI-DropdownHeader"}}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c:"row", a:{"id": "twUI-Dropdown-OptionRoot"}},
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-LeashColorConfig"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Leash Color Config"}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                {c:"row", s:[
                                        {c:"col-3", s:[{c:"round-box", a:{"id" : "twUI-LeashColorPreview"}}
                                            ]},
                                        {c:"col-3", s:[{c: "button", s:[{c:"icon-checkmark"}, {c:"text", h:"Save"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Save the current leash color", "data-action": "saveColor"}}]},
                                    ]},
                                {c:"row", a:{"id": "twUI-LeashColorSliders"}},
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-PiShockLogs"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"PiShockLogs - ", a:{"id" : "twUI-ShockerLogsHeader"}}]},
                                {c:"col-1", s:[{c: "icon-reload", x: "twUI-ButtonAction", a:{"data-tooltip": "Reload PiShock logs", "data-action": "pishockLogsRefresh"}}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", a:{"id" : "twUI-ShockerLogRoot"}, s:[
                                ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-NumberEntry"}, s:[{c: "scroll-view", s:[{c: "content scroll-content", s:[
                                {c: "row", s:[
                                        {c:"col-1", s:[{c: "icon-close", x: "twUI-Back"}]},
                                        {c:"col", s:[{c:"header", h:"Number Input", a:{"id": "twUI-NumberInputHeader"}}]}
                                    ]},
                                {c: "row", s:[
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"1"}], x: "twUI-NumInput", a:{"str": "1"}}]},
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"2"}], x: "twUI-NumInput", a:{"str": "2"}}]},
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"3"}], x: "twUI-NumInput", a:{"str": "3"}}]},
                                        {c:"col", s:[{c: "int-box", s:[{a:{"id" : "twUI-numDisplay", "data-display" : ""}, c:"text", h:""}]}]},
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"icon-checkmark"}], x: "twUI-NumSubmit"}]},
                                    ]},
                                {c: "row", s:[
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"4"}], x: "twUI-NumInput", a:{"str": "4"}}]},
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"5"}], x: "twUI-NumInput", a:{"str": "5"}}]},
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"6"}], x: "twUI-NumInput", a:{"str": "6"}}]},
                                    ]},
                                {c: "row", s:[
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"7"}], x: "twUI-NumInput", a:{"str": "7"}}]},
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"8"}], x: "twUI-NumInput", a:{"str": "8"}}]},
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"9"}], x: "twUI-NumInput", a:{"str": "9"}}]},
                                    ]},
                                {c: "row", s:[
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"icon-back"}], x: "twUI-NumBack"}]},
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"0"}], x: "twUI-NumInput", a:{"str": "0"}}]},
                                        {c:"col-2", s:[{c: "int-button", s:[{c:"button-text", h:"."}], x: "twUI-NumInput", a:{"str": "."}}]},
                                    ]},
                            ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-MenuVisibilityPage"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Menu Settings"}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                    {c: "row", s:[
                                            {c:"col", s:[{c:"header", h:"Menu Settings"}]}
                                        ]},
                                    {c:"row", s: [
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-resize"}, {c:"text", h:"Logo Position Y"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Allows you to change the TW logo position Y, you can set it from -300 to 1460", "data-action": "LogoPositionY"}}]},
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-resize"}, {c:"text", h:"Logo Position X"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Allows you to change the TW logo position X, you can set it from -300 to 1460", "data-action": "LogoPositionX"}}]},
                                        ]},
                                    {c: "row", s:[
                                            {c:"col", s:[{c:"header", h:"Hide Elements"}]}
                                        ]},
                                    {c:"row", a:{"id": "twUI-Settings-ToyControls"}},
                                ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-ShockerManagement"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"Shocker Management"}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                    {c:"row", s: [
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-key"}, {c:"text", h:"Add Shocker"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Adds a shocker to your list", "data-action": "AddShocker"}}]},
                                            {c:"col-3", s:[{c: "button", s:[{c:"icon-reload"}, {c:"text", h:"Refresh Shocker Info"}], x: "twUI-ButtonAction", a:{"data-tooltip": "Refreshes the info for every shocker", "data-action": "RefreshShockerInfo"}}]},
                                        ]},
                                    {c: "row", s:[
                                            {c:"col", s:[{c:"header", h:"Shockers"}]}
                                        ]},
                                    {c:"row", a:{"id": "twUI-ManageShocker-ShockerRoot"}},
                                ]}, {c: "scroll-marker-v"}]}]},
                {c: "container container-controls hide", a:{"id": "twUI-MyAchievements"}, s:[
                        {c: "row header-section", s:[
                                {c:"col-1", s:[{c: "icon-back", x: "twUI-Back"}]},
                                {c:"col", s:[{c:"header", h:"My Achievements"}]}
                            ]},
                        {c: "scroll-view", s:[{c: "content-subpage scroll-content", s:[
                                    {c:"row", a:{"id": "twUI-AchievementRoot"}},
                                ]}, {c: "scroll-marker-v"}]}]},
                {c: "container popup-container hide", a: {"id": "twUI-PopupConfirm"}, s:[
                        {c: "row", s: [
                                {c: "col align-self-center", s: [{c: "header", h: "Notice", a: {"id": "twUI-PopupConfirmHeader"}}]}
                            ]},
                        {c: "content notice-text", h:"This is some text!", a: {"id": "twUI-PopupConfirmText"}},
                        {c: "control-row", s: [
                                {c: "col", s: [{c: "button", s: [{c: "text", h: "Yes", a: {"id": "twUI-PopupConfirmOk"}}], x:"twUI-ConfirmOK"}]},
                                {c: "col", s: [{c: "button", s: [{c: "text", h: "No", a: {"id": "twUI-PopupConfirmNo"}}], x:"twUI-ConfirmNO"}]}
                            ]},
                    ]},
                {c: "container popup-container hide", a: {"id": "twUI-PopupNotice"}, s:[
                        {c:"row", s:[
                                {c:"col align-self-center", s:[{c:"header", h:"Notice", a: {"id": "twUI-PopupNoticeHeader"}}]}
                            ]},
                        {c: "content notice-text", h:"This is some text!", a: {"id": "twUI-PopupNoticeText"}},
                        {c:"row justify-content-center", s:[
                                {c:"col offset-4 align-self-center", s:[{c:"button", s:[{c:"text", h:"OK", a: {"id": "twUI-PopupNoticeOK"}}], x:"twUI-NoticeClose"}]}
                            ]},
                    ]},
                {c: "container-back", s:[{c: "icon"}, {c: "content", h: "Back to main screen"}], x: "switchCategory", a: {"data-category": "quickmenu-home"}},
                {c: "container-tooltip hide", s:[{c:"content", h:"tooltip info", a:{"id": "twUI-Tooltip"}}], a:{"id": "twUI-TooltipContainer"}},
                {c: "container-alertToast hide", s:[{c:"content", h:"toasty!", a:{"id": "twUI-AlertToast"}}], a:{"id": "twUI-AlertToastContainer"}}
            ], a:{"id":"twUI-Root"}};



        menu.templates["twMenuRow"] = {c:"row justify-content-start", a:{"id": "[row-id]"}};
        menu.templates["twPlayerListEntry"] = {c:"col-3", s:[{c:"button-user", x:"twUI-selectPlayer", s:[{c:"text", h:"[player-name]"}], a:{"id": "twUI-PlayerButton-[player-id]-Icon","data-id": "[player-id]", "data-name": "[player-name]", "data-tooltip": "Open up the player options for [player-name]"}}], a:{"id": "twUI-PlayerButton-[player-id]"}};
        menu.templates["twSlider"] = {c:"", s:[{c:"col-12", s:[{c:"text", h:"[slider-name] - [current-value]", a:{"id": "twUI-SliderTitle-[slider-id]", "data-title": "[slider-name]"}}]}, {c: "col-12", s:[{c:"slider", s:[{c:"sliderBar", s:[{c:"slider-knob", a:{"id": "twUI-SliderKnob-[slider-id]"}}], a:{"id": "twUI-SliderBar-[slider-id]"}}], a:{"id":"twUI-Slider-[slider-id]", "data-slider": "[slider-id]", "data-slider-value": "[current-value]", "data-min": "[min-value]", "data-max": "[max-value]"}}], a:{"data-tooltip": "[tooltip-text]"}}]};
        menu.templates["twToggle"] = {c:"col-3", s:[{c: "toggle", s:[{c:"row", s:[{c:"col align-content-start", s:[{c:"enable circle", a:{"id": "twUI-toggle-enable"}}]}, {c:"col align-content-end", s:[{c:"disable circle active", a:{"id": "twUI-toggle-disable"}}]}]},{c:"text-sm", h:"[toggle-name]"}], x: "twUI-Toggle", a:{"id": "twUI-Toggle-[toggle-location]-[toggle-page]-[toggle-id]", "data-toggle": "[toggle-location]-[toggle-page]-[toggle-id]", "data-toggleState": "false", "data-tooltip": "[tooltip-data]"}}]};
        menu.templates["twPetSelectEntry"] = {c:"col-3", s:[{c:"button", x:"twUI-selectPet", s:[{c:"icon-body"}, {c:"text", h:"[player-name]"}], a:{"data-id": "[player-id]", "data-name": "[player-name]", "data-tooltip": "Selects [player-name] for individual pet control"}}], a:{"id": "twUI-PetSelect-[player-id]"}};
        menu.templates["twButton"] = {c:"col-3", s:[{c: "button", s:[{c:"icon-[button-icon]"}, {c:"text", h:"[button-text]"}], x: "twUI-ButtonAction", a:{"data-tooltip": "[button-tooltip]", "data-action": "[button-action]"}}]};
        menu.templates["twMultiSelectOption"] = {c:"col-12", s: [{c:"dropdown-option", s: [{c:"selection-icon"}, {c:"option-text", h: "[option-text]"}], a: {"id": "twUI-DropdownOption-[option-index]", "data-index": "[option-index]"}, x: "twUI-DropdownSelect"}]}
        menu.templates['twShocker'] = {c: "col-4", s: [{c: "shocker", s: [{c: "shocker-container", x: "twUI-Toggle", a: {"id": "twUI-Toggle-[shocker-id]", "data-toggle": "[shocker-id]", "data-toggleState": "false", "data-tooltip": "Toggles the shocker on and off"}, s: [{c: "row", s: [{c: "col-12", s: [{c: "shocker-title", h: "[shocker-name]"}]}]}, {c: "row", s: [{c: "row", s: [{c: "col align-content-start", s: [{c: "enable circle", a: {"id": "twUI-toggle-enable"}}]}, {c: "col align-content-end", s: [{c: "disable circle active", a: {"id": "twUI-toggle-disable"}}]}]}]}]}, {c: "row", s: [{c: "col-6", s: [{c: "shocker-button", s: [{c: "icon-trash"}, {c: "text", h: "Remove"}], x: "twUI-ShockerAction", a: {"data-action": "RemoveShocker", "data-shocker": "[shocker-id]"}}]}, {c: "col-6", s: [{c: "shocker-button", s: [{c: "icon-star"}, {c: "text", h: "Priority"}], x: "twUI-ShockerAction", a: {"data-action": "SetPriority", "data-shocker": "[shocker-id]"}}]}]}, {c: "row bottom-align", s: [{c: "col", s: [{c: "shocker-button-wide", s: [{c: "logs-icon"}, {c: "text", h: "Shocker Logs"}, ], x: "twUI-ShockerAction", a: {"data-action": "OpenLogs", "data-shocker": "[shocker-id]"}}]}]}]}]};
        menu.templates["twShockerLog"] =  {c:"col-1", s:[{c:"log-panel", s:[{c:"col", s:[{c:"log-title", h: "[UserName] - [Origin]"}]}, {c:"row", a:{"id" : "log-row"}, s:[{c:"log-info", h: "Type: [op-type]"}, {c:"log-info", h: "Intensity: [Intensity]%"}, {c:"log-info", h: "Duration: [Duration] Seconds"}]}, {c:"row", a:{"id" : "log-row"}, s:[{c:"log-time", h: "Time: [Timestamp]"}]}]}]}
        menu.templates["twAchievement"] = {c:"col-3", s:[{c: "button", s:[{c: "icon-badge[rank]", a:{"id": "twUI-achievement-image"}}, {c:"text", h: "[name]"}], a: {"data-tooltip": "[description]"}}]};

        menu.templates["core-quickmenu"].l.push("twUI-btn");
        menu.templates["core-quickmenu"].l.push("twUI-menu");

        uiRef.actions["twUI-open"] = this.actions.open;
        uiRef.actions["twUI-Test"] = this.actions.test;
        uiRef.actions["twUI-pushPage"] = this.actions.pushPage;
        uiRef.actions["twUI-Back"] = this.actions.back;
        uiRef.actions["toggleTest"] = this.actions.test;
        uiRef.actions["twUI-selectPlayer"] = this.actions.selectPlayer;
        uiRef.actions["twUI-MakeMaster"] = this.actions.makeMaster;
        uiRef.actions["twUI-MakePet"] = this.actions.makePet;
        uiRef.actions["twUI-ClearLeads"] = this.actions.clearLeads;
        uiRef.actions["twUI-Toggle"] = this.actions.toggle;
        uiRef.actions["twUI-ButtonAction"] = this.actions.buttonAction;
        uiRef.actions["twUI-leadAttachPage"] = this.actions.leadAttachPage;
        uiRef.actions["twUI-LeadAttachAssign"] = this.actions.leadAttachAssign;
        uiRef.actions["twUI-OpenUserManage"] = this.actions.openUserManage;
        uiRef.actions["twUI-ConfirmOK"] = this.actions.confirmOK;
        uiRef.actions["twUI-ConfirmNO"] = this.actions.confirmNo;
        uiRef.actions["twUI-NoticeClose"] = this.actions.noticeClose;
        uiRef.actions["twUI-selectPet"] = this.actions.selectPet;
        uiRef.actions["twUI-OpenParamControlUserMan"] = this.actions.openParamControlFromUserManage;
        uiRef.actions["twUI-OpenParamControlIPC"] = this.actions.openParamControlFromIPC;
        uiRef.actions["twUI-DropdownSelect"] = this.actions.dropdownSelect;
        uiRef.actions["twUI-ShockerAction"] = this.actions.shockerAction;
        uiRef.actions["twUI-NumInput"] = this.actions.numInput;
        uiRef.actions["twUI-NumBack"] = this.actions.numBack;
        uiRef.actions["twUI-NumSubmit"] = this.actions.numSubmit;

        engine.on("twVersionUpdate", this.twVersionUpdate);
        engine.on("twUserCountUpdate", this.twUserCountUpdate);
        engine.on("twStatusUpdate", this.twStatusUpdate);
        engine.on("twAddPlayer", this.twAddPlayer);
        engine.on("twRemovePlayer", this.twRemovePlayer);
        engine.on("twChangeWorld", this.twChangeWorld);
        engine.on("twModInit", this.modInit);
        engine.on("twCreateToggle", this.twCreateToggle);
        engine.on("twSetToggleState", this.twSetToggleState);
        engine.on("twUpdateSelectedBone", this.twUpdateSelectedBone);
        engine.on("twOpenUserManage", this.twOpenUserManage);
        engine.on("twShowConfirm", this.twShowConfirmationBox);
        engine.on("twShowNotice", this.twShowNoticeBox);
        engine.on("twCreateSlider", this.twCreateSlider);
        engine.on("twSliderSetValue", this.twSliderSetValue);
        engine.on("twClearAvatarRemoteConfig", this.twClearAvatarRemoteConfig);
        engine.on("twAvatarRemoteUpdateHeader", this.twAvatarRemoteUpdateHeader);
        engine.on("twAddPet", this.twAddPet);
        engine.on("twRemovePet", this.twRemovePet);
        engine.on("twOpenParamControl", this.twOpenParamControl);
        engine.on("twOpenShockerLogs", this.twOpenShockerLogs);
        engine.on("twClearParamControl", this.twClearParamControl);
        engine.on("twCreateButton", this.twCreateButton);
        engine.on("twOpenMultiSelect", this.twOpenMultiSelect);
        engine.on("twLeadColorChanged", this.twLeadColorChanged);
        engine.on("twOpenNumberInput", this.twOpenNumberInput);
        engine.on("twLeadColorChanged", this.twLeadColorChanged);
        engine.on("twUpdateShockerManagement", this.twUpdateShockerManagement);
        engine.on("twUpdateLogPanel", this.twUpdateLogPanel);
        engine.on("twAlertToast", this.twShowAlert);
        engine.on("twClearAchievementList", this.twClearAchievementList);
        engine.on("twCreateAchievementButton", this.twCreateAchievementButton);
    },

    init: function(menu){
        console.log("TWUI Init");

        this.twCreateSlider("twUI-ControlsSliderRoot", "Leash Length", "leashLengthSlider", 2, 0.3, 10, "Adjust the length of the leash for all pets");
        this.twCreateSlider("twUI-ControlsSliderRoot", "Lovense Strength", "lovenseStrengthSlider", 0, 0, 1, "Control the strength of the toy", ["toyControls"]);

        this.twCreateSlider("twUI-PiShockSliderRoot", "Strength", "piShockStrengthSlider", 0, 0, 100, "PiShock Strength of the shocker.Needs to be lower then whats allowed in the sharesettings");
        this.twCreateSlider("twUI-PiShockSliderRoot", "Duration", "piShockDurationSlider", 0, 0, 15, "PiShock Duration of the shocker. Needs to be lower then whats allowed in the sharesettings");
        this.twCreateSlider("twUI-PiShockSliderRoot", "Shock Height", "piShockHeightSlider", 0, 0, 4, "PiShock Height Control Max Height allowed");
        this.twCreateSlider("twUI-PiShockSliderRoot", "Shock Height Max Strength", "piShockMaxStrengthSlider", 0, 0, 1, "PiShock Height Control Max Strength");
        this.twCreateSlider("twUI-PiShockSliderRoot", "Shock Height Min Strength", "piShockMinStrengthSlider", 0, 0, 1, "PiShock Height Control Min Strength");
        this.twCreateSlider("twUI-PiShockSliderRoot", "Shock Height Step Strength", "piShockStepStrengthSlider", 0, 0, 1, "PiShock Height Control Step Increase");

        this.twCreateSlider("twUI-IPCControlsSliderRoot", "Leash Length", "leashLengthSliderIPC", 2, 0.3, 10, "Adjusts the length of this pet's leash");
        this.twCreateSlider("twUI-IPCControlsSliderRoot", "Lovense Strength", "lovenseStrengthSliderIPC", 0, 0, 1, "Control the strength of the toy", ["toyControls"]);

        this.twCreateSlider("twUI-IPCPiShockSliderRoot", "Strength", "piShockStrengthSliderIPC", 0, 0, 100, "PiShock Strength of the shocker");
        this.twCreateSlider("twUI-IPCPiShockSliderRoot", "Duration", "piShockDurationSliderIPC", 0, 0, 15, "PiShock Duration of the shocker");
        this.twCreateSlider("twUI-IPCPiShockSliderRoot", "Shock Height", "piShockHeightSliderIPC", 0, 0, 4, "PiShock Height Control Max Height allowed");
        this.twCreateSlider("twUI-IPCPiShockSliderRoot", "Shock Height Max Strength", "piShockMaxStrengthSliderIPC", 0, 0, 1, "PiShock Height Control Max Strength");
        this.twCreateSlider("twUI-IPCPiShockSliderRoot", "Shock Height Min Strength", "piShockMinStrengthSliderIPC", 0, 0, 1, "PiShock Height Control Min Strength");
        this.twCreateSlider("twUI-IPCPiShockSliderRoot", "Shock Height Step Strength", "piShockStepStrengthSliderIPC", 0, 0, 1, "PiShock Height Control Step Increase");
        this.twCreateSlider("twUI-LeashColorSliders", "Red", "rFloat", 0, 0, 1, "Adjust red value of lead color");
        this.twCreateSlider("twUI-LeashColorSliders", "Green", "gFloat", 0, 0, 1, "Adjust green value of lead color");
        this.twCreateSlider("twUI-LeashColorSliders", "Blue", "bFloat", 0, 0, 1, "Adjust blue value of lead color");
        this.twCreateSlider("twUI-PetBlindnessSlider", "Blindness Radius", "blindlessSlider", 2, 0, 10, "Adjust the radius of visibility when blindfolded");
        this.twCreateSlider("twUI-PetBlindnessSlider", "Deafen Attenuation", "deafenSlider", -35, -80, 20, "Adjusts the level of volume attenuation when deafened");

        document.addEventListener('mouseover', this.twOnHover);
        document.addEventListener('mousemove', this.twSliderMouseMove);
        document.addEventListener("mouseup", this.twSliderMouseUp);
        document.addEventListener('mousedown', this.twSliderMouseDown);

        engine.call("twUI-UILoaded");
    },

    twLeadColorChanged: function(color){
        let element = document.getElementById("twUI-LeashColorPreview");
        element.style.backgroundColor = "#" + color;
    },

    twOnHover: function (e){
        targetElement = e.target;
        tooltipInfo = null;

        if(targetElement != null) {

            while (tooltipInfo == null && targetElement != null && targetElement.classList != null && !targetElement.classList.contains("menu-category")) {
                tooltipInfo = targetElement.getAttribute("data-tooltip");
                targetElement = targetElement.parentElement;
            }

            if (tooltipInfo != null) {
                document.getElementById("twUI-Tooltip").innerHTML = tooltipInfo;

                cvr("#twUI-TooltipContainer").show();
                return;
            }
        }

        cvr("#twUI-TooltipContainer").hide();
    },

    twChangeWorld: function(){
        cvr("#twUI-PlayerListContent").clear();
        cvr("#twUI-PetSelectionRoot").clear();
        cvr("#twUI-PetSelectionHeader").innerHTML("Selected Pet: None");
    },

    twVersionUpdate: function(verStr){
        cvr(".twUI .container-main .header").innerHTML("Totally Wholesome - " + verStr);
    },

    twUserCountUpdate: function(count){
        cvr(".twUI .container-main .content .user-count").innerHTML("Connected Users: " + count);
    },

    twAddPlayer: function(username, userid, userImage){
        let playerCheck = document.getElementById("twUI-PlayerButton-" + userid);

        if(playerCheck != null) return;

        cvr("#twUI-PlayerListContent").appendChild(cvr.render(uiRef.templates["twPlayerListEntry"], {
            "[player-name]": username,
            "[player-id]": userid,
        }, uiRef.templates, uiRef.actions));

        let user = document.querySelector("#twUI-PlayerButton-" + userid + "-Icon");
        user.style.background = "url('" + userImage + "')";
        user.style.backgroundRepeat = "no-repeat";
        user.style.backgroundSize = "cover";
    },

    twRemovePlayer: function(userid){
        let element = document.querySelector("#twUI-PlayerButton-" + userid);
        if(element != null){
            element.parentElement.removeChild(element);
        }
    },

    modInit: function (hidePiShock, hideToys, logoX, logoY) {
        cvr("#twUI-QMButton").show();

        let piShockElements = document.getElementsByClassName("piShockElements");
        for(let i=0; i<piShockElements.length; i++){
            let element = piShockElements[i];
            console.log(element);
            if(hidePiShock && !element.classList.contains("hide")) {
                element.classList.add("hide");
                element.classList.remove("show");
            }

            if(!hidePiShock && !element.classList.contains("show")) {
                element.classList.remove("hide");
                element.classList.add("show");
            }
        }

        let toyElements = document.getElementsByClassName("toyControls");
        if(toyElements !== null) {
            for (let i = 0; i < toyElements.length; i++) {
                let element = toyElements[i];
                if (hideToys && !element.classList.contains("hide")) {
                    element.classList.add("hide");
                    element.classList.remove("show");
                }

                if (!hideToys && !element.classList.contains("show")) {
                    element.classList.remove("hide");
                    element.classList.add("show");
                }
            }
        }

        let qmButton = document.getElementById("twUI-QMButton");
        qmButton.style.top = logoY + "px";
        qmButton.style.left = logoX + "px";
    },

    twStatusUpdate: function(backgroundColour, textColour, badgeText, displayBadge, petAutoAccept, masterAutoAccept, vibDevice, shockDevice){
        console.log("twStatusUpdate Fired | " + backgroundColour + " | " + textColour + " | " + badgeText + " | " + displayBadge + " | " + petAutoAccept + " | " + masterAutoAccept + " | " + vibDevice + " | " + shockDevice);

        if(displayBadge) {
            cvr("#twUI-badge").show();
        }
        else {
            cvr("#twUI-badge").hide();
        }

        if(petAutoAccept){
            cvr("#twUI-status-pet").show();
        }
        else {
            cvr("#twUI-status-pet").hide();
        }

        if(masterAutoAccept){
            cvr("#twUI-status-master").show();

            let masterAutoElement = document.getElementById("twUI-status-master");

            if(petAutoAccept){
                masterAutoElement.classList.add("status-master-mask");
            }
            else{
                masterAutoElement.classList.remove("status-master-mask");
            }
        }
        else {
            cvr("#twUI-status-master").hide();
        }

        if(vibDevice){
            cvr("#twUI-status-icon-vibrate").show();
        }
        else {
            cvr("#twUI-status-icon-vibrate").hide();
        }

        if(shockDevice){
            cvr("#twUI-status-icon-shock").show();
        }
        else {
            cvr("#twUI-status-icon-shock").hide();
        }

        if(shockDevice || vibDevice){
            cvr("#twUI-status-bg").show();
        }
        else{
            cvr("#twUI-status-bg").hide();
        }

        cvr("#twUI-badgeText").innerHTML(badgeText);
        document.getElementById('twUI-badge').setAttribute('style', 'background-color: ' + backgroundColour + ';');
        document.getElementById('twUI-badgeText').setAttribute('style', 'color: ' + textColour + ';');
    },

    twCreateSlider: function(parent, sliderName, sliderID, currentValue, minValue, maxValue, tooltipText, additionalClasses){
        let parentElement = cvr("#" + parent);

        if(parentElement === null){
            console.error("parentElement wasn't found! Unable to create slider!")
            return;
        }

        let slider = cvr.render(uiRef.templates["twSlider"], {
            "[slider-name]": sliderName,
            "[slider-id]": sliderID,
            "[current-value]": currentValue.toFixed(2),
            "[min-value]": minValue,
            "[max-value]": maxValue,
            "[tooltip-text]": tooltipText,
        }, uiRef.templates, uiRef.actions);

        if(additionalClasses != null) {
            for (let i = 0; i < additionalClasses.length; i++) {
                slider.classList.add(additionalClasses[i]);
            }
        }

        parentElement.appendChild(slider);

        //Set the slider value using our function
        setSliderFunction(sliderID, currentValue);
    },

    twSliderMouseDown: function(e){
        let targetElement = e.target;
        let sliderID = null;

        if(targetElement != null) {
            while (sliderID == null && targetElement != null && targetElement.classList != null && !targetElement.classList.contains("menu-category")) {
                sliderID = targetElement.getAttribute("data-slider");
                if(sliderID == null)
                    targetElement = targetElement.parentElement;
            }
        }

        if (sliderID == null) return;

        isDragging = true;
        currentDraggedSlider = targetElement;
        currentSliderKnob = document.getElementById("twUI-SliderKnob-" + sliderID);
        currentSliderBar = document.getElementById("twUI-SliderBar-" + sliderID);
    },

    twSliderMouseUp: function(e){
        if(currentDraggedSlider === null && !isDragging)
            return;

        currentDraggedSlider = null;
        isDragging = false;
    },

    twSliderMouseMove: function(e){
        if(!isDragging)
            return;
        if(currentDraggedSlider === null)
            return;

        let rect = currentSliderBar.getBoundingClientRect();
        let rectKnob = currentSliderKnob.getBoundingClientRect();
        let start = rect.left;
        let end = rect.right;
        let max = (end - start) - rectKnob.width;
        let current = Math.min(Math.max((e.clientX + 50 - start) - rectKnob.width, 0), max);

        currentSliderKnob.style.left = current + 'px';

        //Update the slider value
        let sliderMin = parseInt(currentDraggedSlider.getAttribute("data-min"));
        let sliderMax = parseInt(currentDraggedSlider.getAttribute("data-max"));

        let newValue = (sliderMax - sliderMin) * (current) / (max) + sliderMin;
        newValue = newValue.toFixed(2);
        currentDraggedSlider.setAttribute("data-slider-value", newValue);

        let sliderID = currentDraggedSlider.getAttribute("data-slider");

        let sliderTitle = document.getElementById("twUI-SliderTitle-" + sliderID);
        sliderTitle.innerHTML = sliderTitle.getAttribute("data-title") + " - " + newValue;

        engine.call("twUI-SliderValueUpdated", sliderID, newValue);
    },

    twSliderSetValue: function (sliderID, value){
        let slider = document.getElementById("twUI-Slider-" + sliderID);
        let sliderKnob = document.getElementById("twUI-SliderKnob-" + sliderID);

        value = Number(value);

        if(slider === null || sliderKnob === null){
            console.error("Unable to set slider value for " + sliderID + "!");
            return;
        }

        let sliderMin = parseInt(slider.getAttribute("data-min"));
        let sliderMax = parseInt(slider.getAttribute("data-max"));

        slider.setAttribute("data-slider-value", value);

        let sliderTitle = document.getElementById("twUI-SliderTitle-" + sliderID);
        if(!Number.isNaN(value))
            sliderTitle.innerHTML = sliderTitle.getAttribute("data-title") + " - " + value.toFixed(2);
        else
            sliderTitle.innerHTML = sliderTitle.getAttribute("data-title") + " - " + value;

        let slider0Max = sliderMax - sliderMin;
        value = value - sliderMin;

        let max = 1021-100;
        sliderKnob.style.left = (value / slider0Max)*max + 'px';
    },

    twShowConfirmationBox: function(title, content, okText, noText){
        let header = document.getElementById("twUI-PopupConfirmHeader");
        let text = document.getElementById("twUI-PopupConfirmText");
        let ok = document.getElementById("twUI-PopupConfirmOk");
        let no = document.getElementById("twUI-PopupConfirmNo");

        header.innerHTML = title;
        text.innerHTML = content;

        if(okText === null){
            ok.innerHTML = "Yes";
        }
        else{
            ok.innerHTML = okText;
        }

        if(noText === null){
            no.innerHTML = "No";
        }
        else{
            no.innerHTML = noText;
        }

        cvr("#twUI-PopupConfirm").show();
    },

    twShowNoticeBox: function(title, content, okText){
        let header = document.getElementById("twUI-PopupNoticeHeader");
        let text = document.getElementById("twUI-PopupNoticeText");
        let ok = document.getElementById("twUI-PopupNoticeOK");

        header.innerHTML = title;
        text.innerHTML = content;

        if(okText === null){
            ok.innerHTML = "Yes";
        }
        else{
            ok.innerHTML = okText;
        }

        cvr("#twUI-PopupNotice").show();
    },

    twCreateToggle: function(settingsCategory, pageID, toggleName, toggleID, tooltip, state)
    {
        let targetRow = cvr("#twUI-" + pageID + "-" + settingsCategory);

        if(targetRow == null) {
            console.error("Attempted to create a settings toggle for a category that doesn't exist! Category=" + settingsCategory)
            return;
        }

        targetRow.appendChild(cvr.render(uiRef.templates["twToggle"], {
            "[toggle-name]": toggleName,
            "[toggle-id]": toggleID,
            "[tooltip-data]": tooltip,
            "[toggle-location]": settingsCategory,
            "[toggle-page]": pageID
        }, uiRef.templates, uiRef.actions));

        newToggle = document.getElementById("twUI-Toggle-" + settingsCategory + "-" + pageID + "-" + toggleID);

        let enabled = newToggle.querySelector("#twUI-toggle-enable");
        let disabled = newToggle.querySelector("#twUI-toggle-disable");

        if(state){
            enabled.classList.add("active");
            disabled.classList.remove("active");
        }
        else{
            enabled.classList.remove("active");
            disabled.classList.add("active");
        }

        newToggle.setAttribute("data-toggleState", state.toString());
    },

    twSetToggleState: function(toggleID, state){
        let element = document.getElementById(toggleID);

        let enabled = element.querySelector("#twUI-toggle-enable");
        let disabled = element.querySelector("#twUI-toggle-disable");

        if(state){
            enabled.classList.add("active");
            disabled.classList.remove("active");
        }
        else{
            enabled.classList.remove("active");
            disabled.classList.add("active");
        }

        element.setAttribute("data-toggleState", state.toString());
    },

    twUpdateSelectedBone: function(bonePage, bone){
        if(bonePage === "master")
            selectedMasterBone = bone;
        if(bonePage === "pet")
            selectedPetBone = bone;
    },
    twOpenUserManage: function (){
        let element = document.getElementById("twUI-UserPermManageHeader");
        element.innerHTML = "Manage User: " + selectedPlayerName;

        cvr("#twUI-PermissionsMenuUsers").show();
        cvr("#twUI-" + currentPage).hide();

        breadcrumbs.push(currentPage);

        engine.call("twUI-OpenedPage", "PermissionsMenuUsers", currentPage);

        currentPage = "PermissionsMenuUsers";
    },
    twClearAvatarRemoteConfig: function (){
        cvr("#twUI-AvatarRemote-FloatParams").clear();

        engine.call("twUI-AvatarRemoteConfigCleared");
    },
    twAvatarRemoteUpdateHeader: function (count){
        let element = document.getElementById("twUI-AvatarRemoteConfigHeader");

        if(element == null){
            return;
        }

        element.innerHTML = "Avatar Remote Config - " + count + "/12 Selected";
    },
    twAddPet: function(username, userid){
        let petCheck = document.getElementById("twUI-PetSelect-" + userid);

        if(petCheck != null) return;

        cvr("#twUI-PetSelectionRoot").appendChild(cvr.render(uiRef.templates["twPetSelectEntry"], {
            "[player-name]": username,
            "[player-id]": userid,
        }, uiRef.templates, uiRef.actions));
    },

    twRemovePet: function(userid){
        if(userid === selectedPetID){
            cvr("#twUI-PetSelectionHeader").innerHTML("Selected Pet: None");
            selectedPetID = "";
            selectedPetName = "";
        }

        let element = document.querySelector("#twUI-PetSelect-" + userid);
        if(element != null){
            element.parentElement.removeChild(element);
        }
    },
    twOpenParamControl: function(){
        cvr("#twUI-RemoteParamControl").show();
        cvr("#twUI-" + currentPage).hide();

        breadcrumbs.push(currentPage);

        engine.call("twUI-OpenedPage", "RemoteParamControl", currentPage);

        currentPage = "RemoteParamControl";
    },
    twOpenShockerLogs: function (shockerName){
        document.getElementById("twUI-ShockerLogsHeader").innerHTML = "PiShockLogs - " + shockerName;

        cvr("#twUI-PiShockLogs").show();
        cvr("#twUI-" + currentPage).hide();

        breadcrumbs.push(currentPage);

        engine.call("twUI-OpenedPage", "PiShockLogs", currentPage);

        currentPage = "PiShockLogs";
    },
    twClearParamControl: function(){
        cvr("#twUI-RemoteControl-MultiSelection").clear();
        cvr("#twUI-RemoteControl-SliderRoot").clear();
        cvr("#twUI-RemoteControl-AvatarButtons").clear();
        cvr("#twUI-RemoteControl-SingleInput").clear();

        engine.call("twUI-RemoteParamControlCleared");
    },
    twCreateButton: function(parent, buttonName, buttonIcon, tooltip, buttonAction){
        cvr("#" + parent).appendChild(cvr.render(uiRef.templates["twButton"], {
            "[button-text]": buttonName,
            "[button-icon]": buttonIcon,
            "[button-tooltip]": tooltip,
            "[button-action]": buttonAction,
        }, uiRef.templates, uiRef.actions));
    },
    twUpdateLogPanel: function (Logs){
        let root = cvr("#twUI-ShockerLogRoot");
        root.clear();
        for(let i=0; i < Logs.length; i++){
            let TimeStamp = Logs[i].Tm.split("T");
            let Date = TimeStamp[0];
            let TimeArray = TimeStamp[1].split(":");
            let Time = TimeArray[0] + ":" + TimeArray[1];
            let Type = "";
            if (Logs[i].Op === 1){
                Type = "Shock"
            }
            if (Logs[i].Op === 2){
                Type = "Vibrate"
            }
            if (Logs[i].Op === 4){
                Type = "Beep"
            }

            root.appendChild(cvr.render(uiRef.templates["twShockerLog"], {
                "[UserName]": Logs[i].Username,
                "[Origin]": Logs[i].Origin,
                "[op-type]": Type,
                "[Intensity]": Logs[i].Intensity,
                "[Duration]": Logs[i].Duration,
                "[Timestamp]": Date + ", " + Time + " UTC",
            }, uiRef.templates, uiRef.actions));
        }
    },
    twOpenMultiSelect: function(name, options, selectedIndex){
        let element = cvr("#twUI-Dropdown-OptionRoot");
        element.clear();

        for(let i=0; i<options.length; i++){
            let option = element.appendChild(cvr.render(uiRef.templates["twMultiSelectOption"], {
                "[option-text]": options[i],
                "[option-index]": i,
            }, uiRef.templates, uiRef.actions));

            let optionIcon = option.querySelector(".selection-icon");
            if(i!==selectedIndex)
                optionIcon.classList.remove("selected");
            if(i===selectedIndex)
                optionIcon.classList.add("selected");
        }

        cvr("#twUI-DropdownHeader").innerHTML(name);

        cvr("#twUI-DropdownPage").show();
        cvr("#twUI-" + currentPage).hide();

        breadcrumbs.push(currentPage);

        engine.call("twUI-OpenedPage", "DropdownPage", currentPage);

        currentPage = "DropdownPage";
    },
    twUpdateShockerManagement: function(shockers) {
          let shockerRoot = cvr("#twUI-ManageShocker-ShockerRoot");
          shockerRoot.clear();

          for(let i=0; i<shockers.length; i++){
              let shocker = shockers[i];

              let shockerElement = shockerRoot.appendChild(cvr.render(uiRef.templates["twShocker"], {
                  "[shocker-name]": shocker.Name,
                  "[shocker-id]": shocker.Key,
              }, uiRef.templates, uiRef.actions));

              let enabled = shockerElement.querySelector("#twUI-toggle-enable");
              let disabled = shockerElement.querySelector("#twUI-toggle-disable");

              if(shocker.Enabled){
                  enabled.classList.add("active");
                  disabled.classList.remove("active");
              }
              else{
                  enabled.classList.remove("active");
                  disabled.classList.add("active");
              }

              let star = shockerElement.querySelector(".icon-star");

              if(shocker.Prioritized) {
                  star.classList.add("icon-star-active");
                  star.classList.remove("icon-star");
              }
              else{
                  star.classList.remove("icon-star-active");
                  star.classList.add("icon-star");
              }

              let shockerToggle = shockerElement.querySelector(".shocker-container");
              shockerToggle.setAttribute("data-toggleState", shocker.Enabled.toString());
          }
    },
    twOpenNumberInput: function(name, number) {
        let display = document.getElementById("twUI-numDisplay");
        let data = number;
        display.setAttribute("data-display", data);
        display.innerHTML = data;

        cvr("#twUI-NumberInputHeader").innerHTML("Editing: " + name);

        uiRef.core.playSoundCore("Click");

        cvr("#twUI-NumberEntry").show();
        cvr("#twUI-" + currentPage).hide();

        breadcrumbs.push(currentPage);

        engine.call("twUI-OpenedPage", "NumberEntry", currentPage);

        currentPage = "NumberEntry";
    },

    twShowAlert: function (message, delay = 5){
        if(twAlertShown){
            twAlertToasts.push({"Message": message, "Delay": delay});
            return;
        }

        cvr("#twUI-AlertToast").innerHTML(message);
        cvr("#twUI-AlertToastContainer").show();
        twAlertShown = true;

        setTimeout(() => {
            cvr("#twUI-AlertToastContainer").hide();
            twAlertShown = false;
            if(twAlertToasts.length > 0){
                let alert = twAlertToasts.shift();
                twShowAlertFunc(alert.Message, alert.Delay);
            }
        }, delay*1000);
    },

    twClearAchievementList(){
        cvr("#twUI-AchievementRoot").clear();
    },

    twCreateAchievementButton(name, description, rank, locked){
        let element = cvr("#twUI-AchievementRoot").appendChild(cvr.render(uiRef.templates["twAchievement"], {
            "[name]": name,
            "[description]": description,
            "[rank]": rank
        }, uiRef.templates, uiRef.actions));

        if(!locked) return;

        let image = element.querySelector("#twUI-achievement-image");
        image.classList.add("locked");
    },

    actions: {
        open: function(){
            uiRef.core.playSoundCore("Click");
            uiRef.core.switchCategorySelected("twUI");

            let elementList = document.getElementById("twUI-Root").getElementsByClassName("slider");

            for (let i=0; i<elementList.length; i++) {
                let slider = elementList[i];
                let sliderID = slider.getAttribute("data-slider");
                let value = slider.getAttribute("data-slider-value");

                setSliderFunction(sliderID, value);
            }

            engine.call("twUI-OpenMainMenu");
        },
        test: function(){
            uiRef.core.playSoundCore("Click");
        },
        pushPage: function (e){
            uiRef.core.playSoundCore("Click");

            let target = e.currentTarget.getAttribute("data-page");

            if(currentPage === target)
                return;

            cvr("#twUI-" + target).show();
            cvr("#twUI-" + currentPage).hide();

            breadcrumbs.push(currentPage);

            engine.call("twUI-OpenedPage", target, currentPage);

            currentPage = target;
        },
        back: function (){
            uiRef.core.playSoundCore("Click");

            let target = breadcrumbs.pop();

            cvr("#twUI-" + target).show();
            cvr("#twUI-" + currentPage).hide();

            engine.call("twUI-BackAction", target, currentPage);

            currentPage = target;
        },
        selectPlayer: function(e){
            uiRef.core.playSoundCore("Click");

            if(currentPage === "PlayerSelectPage")
                return;

            let playerID = e.currentTarget.getAttribute("data-id");
            let playerName = e.currentTarget.getAttribute("data-name");

            selectedPlayerName = playerName;
            selectedPlayerID = playerID;

            cvr("#twUI-PlayerSelectPage").show();
            cvr("#twUI-" + currentPage).hide();

            breadcrumbs.push(currentPage);
            currentPage = "PlayerSelectPage";

            engine.call("twUI-SelectedPlayer", selectedPlayerName, selectedPlayerID);

            cvr("#twUI-PlayerSelectHeader").innerHTML(playerName);
        },
        selectPet: function(e){
            uiRef.core.playSoundCore("Click");

            let playerID = e.currentTarget.getAttribute("data-id");
            let playerName = e.currentTarget.getAttribute("data-name");

            selectedPetName = playerName;
            selectedPetID = playerID;

            engine.call("twUI-SelectPet", selectedPetName, selectedPetID);

            cvr("#twUI-PetSelectionHeader").innerHTML("Selected Pet: " + playerName);
        },
        makeMaster: function(){
            uiRef.core.playSoundCore("Click");
            engine.call("twUI-MakeMaster", selectedPlayerID);
        },
        makePet: function(){
            uiRef.core.playSoundCore("Click");
            engine.call("twUI-MakePet", selectedPlayerID);
        },
        clearLeads: function(){
            uiRef.core.playSoundCore("Click");
            engine.call("twUI-ClearLeads");
        },
        buttonAction: function (e){
            uiRef.core.playSoundCore("Click");
            let action = e.currentTarget.getAttribute("data-action");

            if(action != null){
                engine.call("twUI-ButtonAction", action);
            }
        },
        numInput: function (e){
            let str = e.currentTarget.getAttribute("str");
            let display = document.getElementById("twUI-numDisplay");
            let data = display.getAttribute("data-display");
            if (str === "." && data.includes(".")){
                return;
            }
            if (data.length >= 5){
                return;
            }
            data = data + str;
            display.setAttribute("data-display", data);
            display.innerHTML = data;
        },
        numSubmit: function (){
            let display = document.getElementById("twUI-numDisplay");
            let data = display.getAttribute("data-display");

            if(data != null){
                engine.call("twUI-NumSubmit", data);
            }
            uiRef.core.playSoundCore("Click");

            let target = breadcrumbs.pop();

            cvr("#twUI-" + target).show();
            cvr("#twUI-" + currentPage).hide();

            engine.call("twUI-BackAction", target, currentPage);

            currentPage = target;
        },
        numBack: function (){
            let display = document.getElementById("twUI-numDisplay");
            let data = display.getAttribute("data-display");
            data = data.slice(0, -1);
            display.setAttribute("data-display", data);
            display.innerHTML = data;
        },
        toggle: function(e){
            uiRef.core.playSoundCore("Click");

            let enabled = e.currentTarget.querySelector("#twUI-toggle-enable");
            let disabled = e.currentTarget.querySelector("#twUI-toggle-disable");

            let toggleID = e.currentTarget.getAttribute("data-toggle");
            let state = (e.currentTarget.getAttribute("data-toggleState") === 'true');

            state = !state;

            if(state){
                enabled.classList.add("active");
                disabled.classList.remove("active");
            }
            else{
                enabled.classList.remove("active");
                disabled.classList.add("active");
            }

            e.currentTarget.setAttribute("data-toggleState", state.toString());

            engine.call("twUI-Toggle", toggleID, state);
        },
        leadAttachPage: function(e){
            uiRef.core.playSoundCore("Click");
            let pageMode = e.currentTarget.getAttribute("data-attach");

            let header = document.getElementById("twUI-leadAttachHeader");
            let boneSelection = document.getElementById("twUI-SelectedBone");

            if(pageMode === "pet"){
                header.innerHTML = "Pet Attach Point Selection";
                selectedAttachPage = pageMode;
                boneSelection.innerHTML = "Selected Bone: " + selectedPetBone;
            }
            if(pageMode === "master"){
                header.innerHTML = "Master Attach Point Selection";
                selectedAttachPage = pageMode;
                boneSelection.innerHTML = "Selected Bone: " + selectedMasterBone;
            }

            cvr("#twUI-LeadAttachPage").show();
            cvr("#twUI-" + currentPage).hide();

            breadcrumbs.push(currentPage);
            currentPage = "LeadAttachPage";
        },
        leadAttachAssign: function(e){
            uiRef.core.playSoundCore("Click");
            let bone = e.currentTarget.getAttribute("data-bone");

            let boneSelection = document.getElementById("twUI-SelectedBone");
            boneSelection.innerHTML = "Selected Bone: " + bone;

            if(selectedAttachPage === "pet"){
                selectedPetBone = bone;
            }

            if(selectedAttachPage === "master"){
                selectedMasterBone = bone;
            }

            engine.call("twUI-BoneSelected", selectedAttachPage, bone);
        },
        dropdownSelect: function(e){
              let dropdown = document.getElementById("twUI-Dropdown-OptionRoot");
              let options = dropdown.getElementsByClassName("dropdown-option");
              let index = parseInt(e.currentTarget.getAttribute("data-index"));

              for(let i=0; i<options.length; i++){
                  let option = options[i];
                  let optionIcon = option.querySelector(".selection-icon");
                  if(i!==index)
                      optionIcon.classList.remove("selected");
                  if(i===index)
                      optionIcon.classList.add("selected");
              }

              engine.call("twUI-DropdownSelected", index);
        },
        shockerAction: function(e){
            uiRef.core.playSoundCore("Click");
            let shockerID = e.currentTarget.getAttribute("data-shocker");
            let action = e.currentTarget.getAttribute("data-action");

            console.log(shockerID)
            console.log(action)

            engine.call("twUI-ShockerAction", shockerID, action);
        },
        openUserManage: function (){
            uiRef.core.playSoundCore("Click");
            engine.call("twUI-OpenManageUser", selectedPlayerID)
        },
        confirmOK: function (){
            uiRef.core.playSoundCore("Click");
            engine.call("twUI-PopupConfirmOK");
            cvr("#twUI-PopupConfirm").hide();
        },
        confirmNo: function (){
            uiRef.core.playSoundCore("Click");
            engine.call("twUI-PopupConfirmNo");
            cvr("#twUI-PopupConfirm").hide();
        },
        noticeClose: function (){
            uiRef.core.playSoundCore("Click");
            engine.call("twUI-PopupNoticeOK");
            cvr("#twUI-PopupNotice").hide();
        },
        openParamControlFromIPC: function(){
            uiRef.core.playSoundCore("Click");
            engine.call("twUI-OpenParamControl", selectedPetID);
        },
        openParamControlFromUserManage: function(){
            uiRef.core.playSoundCore("Click");
            engine.call("twUI-OpenParamControl", selectedPlayerID);
        }
    }
}